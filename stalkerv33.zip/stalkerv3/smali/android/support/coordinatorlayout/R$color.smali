.class public final Landroid/support/coordinatorlayout/R$color;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/coordinatorlayout/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static final notification_action_color_filter:I = 0x7f0600b8

.field public static final notification_icon_bg_color:I = 0x7f0600b9

.field public static final ripple_material_light:I = 0x7f0600c5

.field public static final secondary_text_default_material_light:I = 0x7f0600c7


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
