.class public final Landroid/support/asynclayoutinflater/R$id;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/asynclayoutinflater/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final action_container:I = 0x7f09000e

.field public static final action_divider:I = 0x7f090010

.field public static final action_image:I = 0x7f090011

.field public static final action_text:I = 0x7f090019

.field public static final actions:I = 0x7f09001a

.field public static final async:I = 0x7f090030

.field public static final blocking:I = 0x7f090037

.field public static final chronometer:I = 0x7f090059

.field public static final forever:I = 0x7f090098

.field public static final icon:I = 0x7f0900a0

.field public static final icon_group:I = 0x7f0900a1

.field public static final info:I = 0x7f0900a6

.field public static final italic:I = 0x7f0900a7

.field public static final line1:I = 0x7f0900b0

.field public static final line3:I = 0x7f0900b1

.field public static final normal:I = 0x7f0900e3

.field public static final notification_background:I = 0x7f0900e4

.field public static final notification_main_column:I = 0x7f0900e5

.field public static final notification_main_column_container:I = 0x7f0900e6

.field public static final right_icon:I = 0x7f09010d

.field public static final right_side:I = 0x7f09010e

.field public static final tag_transition_group:I = 0x7f090155

.field public static final tag_unhandled_key_event_manager:I = 0x7f090156

.field public static final tag_unhandled_key_listeners:I = 0x7f090157

.field public static final text:I = 0x7f090158

.field public static final text2:I = 0x7f09015a

.field public static final time:I = 0x7f090165

.field public static final title:I = 0x7f090167


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 68
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
