.class public final Landroid/support/coreutils/R$dimen;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/coreutils/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "dimen"
.end annotation


# static fields
.field public static final compat_button_inset_horizontal_material:I = 0x7f0700a2

.field public static final compat_button_inset_vertical_material:I = 0x7f0700a3

.field public static final compat_button_padding_horizontal_material:I = 0x7f0700a4

.field public static final compat_button_padding_vertical_material:I = 0x7f0700a5

.field public static final compat_control_corner_material:I = 0x7f0700a6

.field public static final compat_notification_large_icon_max_height:I = 0x7f0700a7

.field public static final compat_notification_large_icon_max_width:I = 0x7f0700a8

.field public static final notification_action_icon_size:I = 0x7f0701a3

.field public static final notification_action_text_size:I = 0x7f0701a4

.field public static final notification_big_circle_margin:I = 0x7f0701a5

.field public static final notification_content_margin_start:I = 0x7f0701a6

.field public static final notification_large_icon_height:I = 0x7f0701a7

.field public static final notification_large_icon_width:I = 0x7f0701a8

.field public static final notification_main_column_padding_top:I = 0x7f0701a9

.field public static final notification_media_narrow_margin:I = 0x7f0701aa

.field public static final notification_right_icon_size:I = 0x7f0701ab

.field public static final notification_right_side_padding_top:I = 0x7f0701ac

.field public static final notification_small_icon_background_padding:I = 0x7f0701ad

.field public static final notification_small_icon_size_as_large:I = 0x7f0701ae

.field public static final notification_subtext_size:I = 0x7f0701af

.field public static final notification_top_pad:I = 0x7f0701b0

.field public static final notification_top_pad_large_text:I = 0x7f0701b1


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 30
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
