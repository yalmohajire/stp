.class public final Landroid/support/design/R$id;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/design/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final action_bar:I = 0x7f090007

.field public static final action_bar_activity_content:I = 0x7f090008

.field public static final action_bar_container:I = 0x7f090009

.field public static final action_bar_root:I = 0x7f09000a

.field public static final action_bar_spinner:I = 0x7f09000b

.field public static final action_bar_subtitle:I = 0x7f09000c

.field public static final action_bar_title:I = 0x7f09000d

.field public static final action_container:I = 0x7f09000e

.field public static final action_context_bar:I = 0x7f09000f

.field public static final action_divider:I = 0x7f090010

.field public static final action_image:I = 0x7f090011

.field public static final action_menu_divider:I = 0x7f090012

.field public static final action_menu_presenter:I = 0x7f090013

.field public static final action_mode_bar:I = 0x7f090014

.field public static final action_mode_bar_stub:I = 0x7f090015

.field public static final action_mode_close_button:I = 0x7f090016

.field public static final action_text:I = 0x7f090019

.field public static final actions:I = 0x7f09001a

.field public static final activity_chooser_view_content:I = 0x7f09001b

.field public static final add:I = 0x7f09001e

.field public static final alertTitle:I = 0x7f090022

.field public static final async:I = 0x7f090030

.field public static final auto:I = 0x7f090031

.field public static final blocking:I = 0x7f090037

.field public static final bottom:I = 0x7f090039

.field public static final buttonPanel:I = 0x7f09003b

.field public static final center:I = 0x7f090047

.field public static final checkbox:I = 0x7f090057

.field public static final chronometer:I = 0x7f090059

.field public static final container:I = 0x7f090061

.field public static final content:I = 0x7f090062

.field public static final contentPanel:I = 0x7f090063

.field public static final coordinator:I = 0x7f090064

.field public static final custom:I = 0x7f090067

.field public static final customPanel:I = 0x7f090068

.field public static final decor_content_parent:I = 0x7f09006c

.field public static final default_activity_button:I = 0x7f09006d

.field public static final design_bottom_sheet:I = 0x7f09006f

.field public static final design_menu_item_action_area:I = 0x7f090070

.field public static final design_menu_item_action_area_stub:I = 0x7f090071

.field public static final design_menu_item_text:I = 0x7f090072

.field public static final design_navigation_view:I = 0x7f090073

.field public static final edit_query:I = 0x7f090082

.field public static final end:I = 0x7f090083

.field public static final expand_activities_button:I = 0x7f09008d

.field public static final expanded_menu:I = 0x7f09008e

.field public static final fill:I = 0x7f090090

.field public static final filled:I = 0x7f090093

.field public static final fixed:I = 0x7f090096

.field public static final forever:I = 0x7f090098

.field public static final ghost_view:I = 0x7f09009b

.field public static final group_divider:I = 0x7f09009d

.field public static final home:I = 0x7f09009e

.field public static final icon:I = 0x7f0900a0

.field public static final icon_group:I = 0x7f0900a1

.field public static final image:I = 0x7f0900a4

.field public static final info:I = 0x7f0900a6

.field public static final italic:I = 0x7f0900a7

.field public static final item_touch_helper_previous_elevation:I = 0x7f0900a8

.field public static final labeled:I = 0x7f0900aa

.field public static final largeLabel:I = 0x7f0900ab

.field public static final left:I = 0x7f0900ac

.field public static final line1:I = 0x7f0900b0

.field public static final line3:I = 0x7f0900b1

.field public static final listMode:I = 0x7f0900b3

.field public static final list_item:I = 0x7f0900b4

.field public static final masked:I = 0x7f0900be

.field public static final message:I = 0x7f0900c5

.field public static final mini:I = 0x7f0900c7

.field public static final mtrl_child_content_container:I = 0x7f0900d6

.field public static final mtrl_internal_children_alpha_tag:I = 0x7f0900d7

.field public static final multiply:I = 0x7f0900d8

.field public static final navigation_header_container:I = 0x7f0900de

.field public static final none:I = 0x7f0900e2

.field public static final normal:I = 0x7f0900e3

.field public static final notification_background:I = 0x7f0900e4

.field public static final notification_main_column:I = 0x7f0900e5

.field public static final notification_main_column_container:I = 0x7f0900e6

.field public static final outline:I = 0x7f0900e9

.field public static final parallax:I = 0x7f0900ee

.field public static final parentPanel:I = 0x7f0900f0

.field public static final parent_matrix:I = 0x7f0900f1

.field public static final pin:I = 0x7f0900f4

.field public static final progress_circular:I = 0x7f090103

.field public static final progress_horizontal:I = 0x7f090104

.field public static final radio:I = 0x7f090106

.field public static final right:I = 0x7f09010c

.field public static final right_icon:I = 0x7f09010d

.field public static final right_side:I = 0x7f09010e

.field public static final save_image_matrix:I = 0x7f090110

.field public static final save_non_transition_alpha:I = 0x7f090111

.field public static final save_scale_type:I = 0x7f090112

.field public static final screen:I = 0x7f090113

.field public static final scrollIndicatorDown:I = 0x7f090115

.field public static final scrollIndicatorUp:I = 0x7f090116

.field public static final scrollView:I = 0x7f090118

.field public static final scrollable:I = 0x7f090119

.field public static final search_badge:I = 0x7f09011b

.field public static final search_bar:I = 0x7f09011c

.field public static final search_button:I = 0x7f09011d

.field public static final search_close_btn:I = 0x7f09011e

.field public static final search_edit_frame:I = 0x7f090120

.field public static final search_go_btn:I = 0x7f090122

.field public static final search_mag_icon:I = 0x7f090123

.field public static final search_plate:I = 0x7f090124

.field public static final search_src_text:I = 0x7f090125

.field public static final search_voice_btn:I = 0x7f090128

.field public static final select_dialog_listview:I = 0x7f09012a

.field public static final selected:I = 0x7f09012b

.field public static final shortcut:I = 0x7f090138

.field public static final smallLabel:I = 0x7f09013e

.field public static final snackbar_action:I = 0x7f09013f

.field public static final snackbar_text:I = 0x7f090140

.field public static final spacer:I = 0x7f090145

.field public static final split_action_bar:I = 0x7f090146

.field public static final src_atop:I = 0x7f090149

.field public static final src_in:I = 0x7f09014a

.field public static final src_over:I = 0x7f09014b

.field public static final start:I = 0x7f09014d

.field public static final stretch:I = 0x7f090150

.field public static final submenuarrow:I = 0x7f090151

.field public static final submit_area:I = 0x7f090152

.field public static final tabMode:I = 0x7f090153

.field public static final tag_transition_group:I = 0x7f090155

.field public static final tag_unhandled_key_event_manager:I = 0x7f090156

.field public static final tag_unhandled_key_listeners:I = 0x7f090157

.field public static final text:I = 0x7f090158

.field public static final text2:I = 0x7f09015a

.field public static final textSpacerNoButtons:I = 0x7f09015b

.field public static final textSpacerNoTitle:I = 0x7f09015c

.field public static final text_input_password_toggle:I = 0x7f090161

.field public static final textinput_counter:I = 0x7f090162

.field public static final textinput_error:I = 0x7f090163

.field public static final textinput_helper_text:I = 0x7f090164

.field public static final time:I = 0x7f090165

.field public static final title:I = 0x7f090167

.field public static final titleDividerNoCustom:I = 0x7f090168

.field public static final title_template:I = 0x7f09016a

.field public static final top:I = 0x7f09016c

.field public static final topPanel:I = 0x7f09016d

.field public static final touch_outside:I = 0x7f09016f

.field public static final transition_current_scene:I = 0x7f090170

.field public static final transition_layout_save:I = 0x7f090171

.field public static final transition_position:I = 0x7f090172

.field public static final transition_scene_layoutid_cache:I = 0x7f090173

.field public static final transition_transform:I = 0x7f090174

.field public static final uniform:I = 0x7f09017a

.field public static final unlabeled:I = 0x7f09017b

.field public static final up:I = 0x7f09017c

.field public static final view_offset_helper:I = 0x7f090187

.field public static final visible:I = 0x7f090189

.field public static final wrap_content:I = 0x7f090195


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 985
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
