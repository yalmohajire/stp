.class public final Landroid/support/compat/R$style;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/compat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static final TextAppearance_Compat_Notification:I = 0x7f100124

.field public static final TextAppearance_Compat_Notification_Info:I = 0x7f100125

.field public static final TextAppearance_Compat_Notification_Line2:I = 0x7f100127

.field public static final TextAppearance_Compat_Notification_Time:I = 0x7f10012a

.field public static final TextAppearance_Compat_Notification_Title:I = 0x7f10012c

.field public static final Widget_Compat_NotificationActionContainer:I = 0x7f1001d5

.field public static final Widget_Compat_NotificationActionText:I = 0x7f1001d6


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 112
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
